# Warehouse Segmentation > 2025-09-23 8:48am
https://universe.roboflow.com/warehousespartial/warehouse-segmentation-y0wbo

Provided by a Roboflow user
License: CC BY 4.0

